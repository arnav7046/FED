import React from 'react'

const AlbumDetails = () => {
  return (
    <div>
      
    </div>
  )
}

export default AlbumDetails
